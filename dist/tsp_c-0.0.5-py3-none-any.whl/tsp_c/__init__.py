"""
``tsp_c``
=========================
"""

from .tsp import solve_greedy  # noqa
from .tsp import solve_SA  # noqa
from .tsp import set_param_SA  # noqa
