# tsp-c Package

A wrapper for c++ to solve the Traveling Salesman Problem